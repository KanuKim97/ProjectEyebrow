package com.example.projecteyebrow

import android.app.Application

class AndroidApp: Application()