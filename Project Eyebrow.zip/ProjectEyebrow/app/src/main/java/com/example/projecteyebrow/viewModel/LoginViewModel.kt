package com.example.projecteyebrow.viewModel

class LoginViewModel {
}