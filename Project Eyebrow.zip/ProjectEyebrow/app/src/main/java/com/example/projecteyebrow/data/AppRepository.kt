package com.example.projecteyebrow.data

class AppRepository {
}