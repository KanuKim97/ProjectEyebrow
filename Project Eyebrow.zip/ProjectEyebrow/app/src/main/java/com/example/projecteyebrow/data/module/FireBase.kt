package com.example.projecteyebrow.data.module

interface FireBase {
}